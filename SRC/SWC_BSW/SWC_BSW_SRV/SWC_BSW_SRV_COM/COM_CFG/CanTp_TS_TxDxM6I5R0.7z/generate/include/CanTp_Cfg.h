/**
 * \file
 *
 * \brief AUTOSAR CanTp
 *
 * This file contains the implementation of the AUTOSAR
 * module CanTp.
 *
 * \author Elektrobit Automotive GmbH, 91058 Erlangen, Germany
 *
 * Copyright 2005 - 2013 Elektrobit Automotive GmbH
 * All rights exclusively reserved for Elektrobit Automotive GmbH,
 * unless expressly agreed to otherwise.
 */
[!CODE!]
#if(!defined CANTP_CFG_H)
#define CANTP_CFG_H

/* CanTp_Cfg.h shall define constant and customizable data for module configuration
   at pre-compile time.
 */
/* !LINKSTO CanTp.ASR40.CANTP001, 1 */
/*==================[includes]===============================================*/
[!INCLUDE "CanTp_Precompile.m"!][!//
[!INCLUDE "CanTp_PostBuild.m"!][!//
#include <TSAutosar.h>      /* EB specific standard types */
#include <ComStack_Types.h> /* typedefs for AUTOSAR com stack */

/*==================[macros]=================================================*/

/** \brief switch for supporting PbcgfM module */
[!IF "node:contains(node:refs(as:modconf('PbcfgM')/PbcfgMBswModules/*/PbcfgMBswModuleRef), as:modconf('CanTp')) = 'true'"!]
#define CANTP_PBCFGM_SUPPORT_ENABLED      STD_ON
/** \brief switch reports that if PbcfgM module is configured
** and PbcfgMGeneral\PbcfgMMapIsValidFunctionToMemSection exists
** and is true then enable BSWMD to generate a new memory section
*/
[!IF "node:exists(as:modconf('PbcfgM')[1]/PbcfgMGeneral/PbcfgMMapIsValidFunctionToMemSection)"!]
[!IF "as:modconf('PbcfgM')[1]/PbcfgMGeneral/PbcfgMMapIsValidFunctionToMemSection = 'true'"!]
#define CANTP_ISVALIDCONFIG_MMAP_ENABLED  STD_ON
[!ELSE!]
#define CANTP_ISVALIDCONFIG_MMAP_ENABLED  STD_OFF
[!ENDIF!]
[!ELSE!]
#define CANTP_ISVALIDCONFIG_MMAP_ENABLED  STD_OFF
[!ENDIF!]

[!ELSE!]
#define CANTP_PBCFGM_SUPPORT_ENABLED      STD_OFF
#define CANTP_ISVALIDCONFIG_MMAP_ENABLED  STD_OFF
[!ENDIF!]


/** \brief Switch for DET usage */
[!IF "CanTpGeneral/CanTpDevErrorDetect = 'true'"!][!//
#define CANTP_DEV_ERROR_DETECT            STD_ON
[!ELSE!][!//
#define CANTP_DEV_ERROR_DETECT            STD_OFF
[!ENDIF!][!//

/** \brief Switch for GetVersionInfo API */
[!IF "CanTpGeneral/CanTpVersionInfoApi = 'true'"!][!//
#define CANTP_VERSION_INFO_API            STD_ON
[!ELSE!][!//
#define CANTP_VERSION_INFO_API            STD_OFF
[!ENDIF!][!//

/** \brief Defines if receive cancellation API is available. */
[!IF "CanTpGeneral/CanTpCancelReceiveApi = 'true'"!][!//
#define CANTP_RX_CANCELLATION_API          STD_ON
[!ELSE!][!//
#define CANTP_RX_CANCELLATION_API          STD_OFF
[!ENDIF!][!//

/** \brief Defines if transmit cancellation API is available. */
[!IF "CanTpGeneral/CanTpCancelTransmitApi = 'true'"!][!//
#define CANTP_TX_CANCELLATION_API          STD_ON
[!ELSE!][!//
#define CANTP_TX_CANCELLATION_API          STD_OFF
[!ENDIF!][!//

/** \brief Handling of N_SA values
 **
 ** The macro CANTP_DYNAMIC_NSA_ENABLED is used to specify if N_SA values are fix values,
 ** which are specified at configuration time (normal Autosar behaviour) or
 ** it is possible to change the N_SA values for each
 ** Pdu at runtime. If enabled, change at runtime is possible.
 */
[!IF "CanTpGeneral/CanTpDynamicNSaEnabled = 'true'"!][!//
#define CANTP_DYNAMIC_NSA_ENABLED   STD_ON
#define CANTP_DYNAMIC_NSA_API       STD_ON
[!ELSE!][!//
#define CANTP_DYNAMIC_NSA_ENABLED   STD_OFF
#define CANTP_DYNAMIC_NSA_API       STD_OFF
[!ENDIF!][!//

/** \brief defines if CanTp_ChangeParameter() is enabled */
[!IF "CanTpGeneral/CanTpChangeParameterApi = 'true'"!][!//
#define CANTP_CHANGE_PARAMETER_REQ_API    STD_ON
[!ELSE!][!//
#define CANTP_CHANGE_PARAMETER_REQ_API    STD_OFF
[!ENDIF!][!//

/* jumptable related macros */

/** \brief Jumptable support is deactivated */
#define CANTP_JUMPTABLE_OFF             0U
/** \brief Jumptable support is activated and module acts as server */
#define CANTP_JUMPTABLE_SERVER          1U
/** \brief Jumptable support is activated and module acts as client */
#define CANTP_JUMPTABLE_CLIENT          2U

/** \brief General CanTp jumptable support */
#define CANTP_JUMPTABLE_SUPPORT           [!IF "CanTpJumpTable/CanTpJumpTableMode = 'OFF'"!]STD_OFF[!ELSE!]STD_ON[!ENDIF!]

/** \brief CanTp jumptable mode
 **
 ** This macro defines the current jumptable mode (not supported, server,
 ** client).
 */
#define CANTP_JUMPTABLE_MODE              CANTP_JUMPTABLE_[!"CanTpJumpTable/CanTpJumpTableMode"!]

/** \brief CanTp jumptable support: SchM used as macro
 **
 ** This macro defines, if the SchM functions shall be accessed via function
 ** pointers in the exit jumptable (value STD_ON) or if macros are defined
 ** and used for them (value STD_OFF).
 */
[!IF "(CanTpJumpTable/CanTpJumpTableMode != 'OFF') and (CanTpJumpTable/CanTpUseSchMMacros = 'false')"!][!//
#define CANTP_EXIT_JUMPTABLE_WITH_SCHM    STD_ON
[!ELSE!][!//
#define CANTP_EXIT_JUMPTABLE_WITH_SCHM    STD_OFF
[!ENDIF!][!//

/** \brief CanTp jumptable configuration
 **
 ** This macro defines if the current CanTp shall provide the entry jumptable
 ** to the application (value STD_ON) or if the CanTp functions are provided
 ** (value STD_OFF).
 */
[!IF "CanTpJumpTable/CanTpJumpTableMode = 'SERVER'"!][!//
#define CANTP_PROVIDE_JUMPTABLE           STD_ON
[!ELSE!][!//
#define CANTP_PROVIDE_JUMPTABLE           STD_OFF
[!ENDIF!][!//

/** \brief Defines if the CanTp provides all of its API functions
 **
 ** This macro defines if the CanTp shall provide all of its API functions. If
 ** jumptable support is on and wrapper macros shall be used, this macro has
 ** the value STD_OFF. Otherwise it is STD_ON.
 */
[!IF "$CanTpProvideApiFunctions = 'true'"!][!//
#define CANTP_PROVIDE_API_FUNCTIONS       STD_ON
[!ELSE!][!//
#define CANTP_PROVIDE_API_FUNCTIONS       STD_OFF
[!ENDIF!][!//

/** \brief defines if general purpose timer is enabled for timeout handling of the channels */
[!IF "CanTpGeneral/CanTpGptUsageEnable = 'true'"!][!//
#define CANTP_USE_GPT  STD_ON
[!ELSE!][!//
#define CANTP_USE_GPT  STD_OFF
[!ENDIF!][!//

/** \brief Maximum number TX channels supported.
 */
#define CANTP_MAX_TX_CHANNELS [!"num:i(as:modconf('CanTp')[1]/CanTpGeneral/CanTpMaxTxChannels)"!]U

/** \brief Maximum number RX channels supported.
 */
#define CANTP_MAX_RX_CHANNELS [!"num:i(as:modconf('CanTp')[1]/CanTpGeneral/CanTpMaxRxChannels)"!]U

/** \brief Maximum number TX N-SDUs supported.
 */
#define CANTP_MAX_TX_NSDUS [!"num:i(as:modconf('CanTp')[1]/CanTpGeneral/CanTpMaxTxNSdus)"!]U

/** \brief Maximum number RX N-SDUs supported.
 */
#define CANTP_MAX_RX_NSDUS [!"num:i(as:modconf('CanTp')[1]/CanTpGeneral/CanTpMaxRxNSdus)"!]U

/** \brief Maximum number flow control PDUs supported.
 */
#define CANTP_MAX_FC_PDUS [!"num:i(as:modconf('CanTp')[1]/CanTpGeneral/CanTpMaxFcPdus)"!]U

/* ----- Pre-processor switch to enable/diable relocateable postbuild config ----- */
#if(CANTP_PBCFGM_SUPPORT_ENABLED == STD_ON)
#define CANTP_RELOCATABLE_CFG_ENABLE  [!//
[!IF "as:modconf('PbcfgM')/PbcfgMGeneral/PbcfgMRelocatableCfgEnable = 'true'"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!][!/*
*/!]
#else
#define CANTP_RELOCATABLE_CFG_ENABLE  [!//
[!IF "CanTpGeneral/CanTpRelocatablePbcfgEnable = 'true'"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!][!/*
*/!]
#endif

/** \brief Compile time verification value */
#define CANTP_CFG_SIGNATURE [!"asc:getConfigSignature(node:difference(as:modconf('CanTp')[1]//*[not(child::*) and (node:configclass() = 'PreCompile')],as:modconf('CanTp')[1]/CanTpJumpTable/*))"!]U

/** \brief Compile time Published information configuration verification value */
#define CANTP_PUBLIC_INFO_SIGNATURE [!"asc:getConfigSignature(node:difference(as:modconf('CanTp')[1]/CommonPublishedInformation//*[not(child::*) and (node:configclass() = 'PublishedInformation') ], as:modconf('CanTp')[1]/CommonPublishedInformation/Release))"!]U




/*------------------[Defensive programming]---------------------------------*/
[!SELECT "CanTpDefensiveProgramming"!][!//

#if (defined CANTP_DEFENSIVE_PROGRAMMING_ENABLED)
#error CANTP_DEFENSIVE_PROGRAMMING_ENABLED is already defined
#endif
/** \brief Defensive programming usage
 **
 ** En- or disables the usage of the defensive programming */
#define CANTP_DEFENSIVE_PROGRAMMING_ENABLED   [!//
[!IF "(../CanTpGeneral/CanTpDevErrorDetect  = 'true') and (CanTpDefProgEnabled = 'true')"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!]

#if (defined CANTP_PRECONDITION_ASSERT_ENABLED)
#error CANTP_PRECONDITION_ASSERT_ENABLED is already defined
#endif
/** \brief Precondition assertion usage
 **
 ** En- or disables the usage of precondition assertion checks */
#define CANTP_PRECONDITION_ASSERT_ENABLED     [!//
[!IF "(../CanTpGeneral/CanTpDevErrorDetect  = 'true') and (CanTpDefProgEnabled = 'true') and (CanTpPrecondAssertEnabled = 'true')"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!]

#if (defined CANTP_POSTCONDITION_ASSERT_ENABLED)
#error CANTP_POSTCONDITION_ASSERT_ENABLED is already defined
#endif
/** \brief Postcondition assertion usage
 **
 ** En- or disables the usage of postcondition assertion checks */
#define CANTP_POSTCONDITION_ASSERT_ENABLED    [!//
[!IF "(../CanTpGeneral/CanTpDevErrorDetect  = 'true') and (CanTpDefProgEnabled = 'true') and (CanTpPostcondAssertEnabled = 'true')"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!]

#if (defined CANTP_UNREACHABLE_CODE_ASSERT_ENABLED)
#error CANTP_UNREACHABLE_CODE_ASSERT_ENABLED is already defined
#endif
/** \brief Unreachable code assertion usage
 **
 ** En- or disables the usage of unreachable code assertion checks */
#define CANTP_UNREACHABLE_CODE_ASSERT_ENABLED [!//
[!IF "(../CanTpGeneral/CanTpDevErrorDetect  = 'true') and (CanTpDefProgEnabled = 'true') and (CanTpUnreachAssertEnabled = 'true')"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!]

#if (defined CANTP_INVARIANT_ASSERT_ENABLED)
#error CANTP_INVARIANT_ASSERT_ENABLED is already defined
#endif
/** \brief Invariant assertion usage
 **
 ** En- or disables the usage of invariant assertion checks */
#define CANTP_INVARIANT_ASSERT_ENABLED        [!//
[!IF "(../CanTpGeneral/CanTpDevErrorDetect  = 'true') and (CanTpDefProgEnabled = 'true') and (CanTpInvariantAssertEnabled = 'true')"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!]

#if (defined CANTP_STATIC_ASSERT_ENABLED)
#error CANTP_STATIC_ASSERT_ENABLED is already defined
#endif
/** \brief Static assertion usage
 **
 ** En- or disables the usage of static assertion checks */
#define CANTP_STATIC_ASSERT_ENABLED           [!//
[!IF "(../CanTpGeneral/CanTpDevErrorDetect  = 'true') and (CanTpDefProgEnabled = 'true') and (CanTpStaticAssertEnabled = 'true')"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!]

[!ENDSELECT!][!//


/*====================[Symbolic Names]=======================================*/

/*==================[type definitions]=======================================*/

/*==================[external constants]=====================================*/

/*==================[external data]==========================================*/

/*==================[internal data]=========================================*/

/*==================[external function declarations]=========================*/
#define CANTP_START_SEC_CODE
#include <MemMap.h>

  [!IF "CanTpGeneral/CanTpGptUsageEnable = 'true'"!]
  [!FOR "I"="0" TO "$numTxChannels - 1"!]
  [!VAR "chanRef"!][!CALL "getChanRefByChanId", "chanId"="$I"!][!ENDVAR!]
  [!IF "node:ref($chanRef)/CanTpSTminTimeoutHandling = 'Gpt'"!]
  [!VAR "callbackName"="node:ref($chanRef)/CanTpGptChannelCallbackName"!]
  /** \brief [!"$callbackName"!]()
  **
  ** This function is called by the Gpt as callback function
  ** for channel [!"node:name(node:ref($chanRef))"!]
  **
  ** Redirect function call to STmin callback with channel as parameter
  */
  extern FUNC(void, CANTP_CODE) [!"$callbackName"!](void);

  [!ENDIF!]
  [!ENDFOR!]
  [!ENDIF!][!//"CanTpGeneral/CanTpGptUsageEnable = 'true'"

#define CANTP_STOP_SEC_CODE
#include <MemMap.h>
/*==================[end of file]============================================*/
#endif /* if !defined( CANTP_CFG_H ) */
[!ENDCODE!]
